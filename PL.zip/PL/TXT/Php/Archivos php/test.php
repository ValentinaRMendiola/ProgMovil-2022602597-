<?php
echo "Hola mundo";
